/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _INC_TRUECRYPT_KEYFILE_H
#define _INC_TRUECRYPT_KEYFILE_H

DECLSPEC u32 u8add (const u32 a, const u32 b);

#endif // _INC_TRUECRYPT_KEYFILE_H
