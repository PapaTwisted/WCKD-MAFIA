/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _SELFTEST_H
#define _SELFTEST_H

HC_API_CALL void *thread_selftest (void *p);

#endif // _SELFTEST_H
