/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _BENCHMARK_H
#define _BENCHMARK_H

int benchmark_next (hashcat_ctx_t *hashcat_ctx);

#endif // _BENCHMARK_H
