/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#ifndef _AUTOTUNE_H
#define _AUTOTUNE_H

HC_API_CALL void *thread_autotune (void *p);

#endif // _AUTOTUNE_H
