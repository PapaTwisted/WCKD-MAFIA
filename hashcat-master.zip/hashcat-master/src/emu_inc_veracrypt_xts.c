/**
 * Author......: See docs/credits.txt
 * License.....: MIT
 */

#include "common.h"
#include "types.h"
#include "emu_general.h"

#include "inc_veracrypt_xts.cl"

