# Kismet Linux Bluetooth

Uses the bluez management socket API to initiate scans for devices

