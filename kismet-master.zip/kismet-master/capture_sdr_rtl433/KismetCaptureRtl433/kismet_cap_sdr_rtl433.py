import sys
import time
import KismetCaptureRtl433

def main():
    rtl = KismetCaptureRtl433.KismetRtl433()

    rtl.run()

